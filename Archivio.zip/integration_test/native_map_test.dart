@Tags(['native'])
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:concessionario_supercar/main.dart' as app;

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('Open app and navigate to a view that uses native plugins', (tester) async {
    app.main();
    await tester.pumpAndSettle(const Duration(seconds: 12));

    // Qui tocca una tab o un pulsante che porta a una vista con GoogleMap / geolocator
    // Esempio (adatta alla tua UI):
    // await tester.tap(find.textContaining('Mappa'));
    // await tester.pumpAndSettle(const Duration(seconds: 8));

    // Verifica che l'app non crashi e che la UI resti reattiva
    expect(find.byType(AppBottomBar), findsOneWidget);
  });
}